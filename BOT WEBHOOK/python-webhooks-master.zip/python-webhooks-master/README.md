# Python Webhooks
These are basic examples for my Python Webhook videos:


### Sending Webhooks with python
https://www.youtube.com/watch?v=X-_25tzo8Cw&feature=youtu.be
```shell
python webhook.py
```

### Receiving Webhooks with Python:
https://www.youtube.com/watch?v=HQLRPWi2SeA
```shell
python server.py
```